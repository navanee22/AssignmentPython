def ordersprod(product):
    return 10