def invoiceProd(price):
    return price+(price*7/100)